

// qustion =1

// function isUppercase(str) {
//     return str === str.toUpperCase();
// }

// function isLowercase(str) {
//     return str === str.toLowerCase();
// }



// // Example usage
// console.log(isUppercase("sss")); // true
// console.log(isLowercase("hello")); // true
// console.log(isUppercase("Hello")); // false
// console.log(isLowercase("Hello")); // false



qustion =2


// var a =prompt("enter your number ")
// var b=prompt("enter your 2nd number ")

// if(a<b){

//     console.log("a is greter");
// }
// else{

//     console.log("B is greter");
// }



// qustion =3


// var a =prompt("enter your number ")


// if(a>0){

//     console.log("number is pasitive");
// }
// else{

//     console.log("number is negative");
// }


// qustion= 4

// function isVowel(char) {
//     // Convert the character to lowercase to make the check case-insensitive
//     char = char.toLowerCase();

//     // Check if the character is one of the vowels
//     return char === 'a' || char === 'e' || char === 'i' || char === 'o' || char === 'u';
// }

// // Example usage
// console.log(isVowel('a')); // true
// console.log(isVowel('b')); // false
// console.log(isVowel('E')); // true
// console.log(isVowel('z')); // false


// qustion= 6

// var hour = 13;
// if (hour < 18) {

// console.log("Good day");
// }
// else{
//     console.log("Good evening");

// }



// qustion= 7

// var time =prompt("enter your number ")

// switch(time){

//     case "1300":

//     console.log("01:00");

//     break ;

//     case "1400":

//     console.log("02:00");

//     break ;


//     case "1500":

//     console.log("03:00");

//     break ;


//     case "1600":

//     console.log("04:00");

//     break ;


//     case "1700":

//     console.log("05:00");

//     break ;

//     case "1800":

//     console.log("06:00");

//     break ;


//     case "1900":

//     console.log("07:00");

//     break ;


//     case "2000":

//     console.log("08:00");

//     break ;


//     default:
//         text = "Enter your corect time ...";



// }

let studentNames=[]



str =studentNames=[ali]


console.log(studentNames);